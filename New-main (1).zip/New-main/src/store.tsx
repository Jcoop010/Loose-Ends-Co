import { createContext, useCallback, useContext, useEffect, useState, type ReactNode } from 'react'
import type { AppData, Opportunity, FollowUp, Request, Lead } from './types'
import { seedData, STORAGE_KEY } from './data'

function genId(prefix = 'id'): string {
  return `${prefix}_${Math.random().toString(36).substring(2, 10)}`
}

function loadData(): AppData {
  try {
    const stored = localStorage.getItem(STORAGE_KEY)
    if (stored) {
      const parsed = JSON.parse(stored)
      return { ...seedData, ...parsed }
    }
  } catch {
    // ignore
  }
  return seedData
}

interface StoreContextValue {
  data: AppData
  updateOpportunity: (id: string, updates: Partial<Opportunity>) => void
  updateFollowUp: (id: string, updates: Partial<FollowUp>) => void
  dismissAlert: (id: string) => void
  addRequest: (req: Omit<Request, 'id' | 'createdAt'>) => void
  updateRequest: (id: string, updates: Partial<Request>) => void
  addLead: (lead: Omit<Lead, 'id' | 'createdAt'>) => void
  addNoteToCustomer: (customerId: string, note: string) => void
  addOpportunity: (opp: Omit<Opportunity, 'id'>) => void
  addFollowUp: (fu: Omit<FollowUp, 'id'>) => void
  dismissFollowUp: (id: string) => void
  resetData: () => void
}

const StoreContext = createContext<StoreContextValue | null>(null)

export function StoreProvider({ children }: { children: ReactNode }) {
  const [data, setData] = useState<AppData>(loadData)

  useEffect(() => {
    try {
      localStorage.setItem(STORAGE_KEY, JSON.stringify(data))
    } catch {
      // ignore
    }
  }, [data])

  const updateOpportunity = useCallback((id: string, updates: Partial<Opportunity>) => {
    setData(prev => ({
      ...prev,
      opportunities: prev.opportunities.map(o => (o.id === id ? { ...o, ...updates } : o)),
    }))
  }, [])

  const updateFollowUp = useCallback((id: string, updates: Partial<FollowUp>) => {
    setData(prev => ({
      ...prev,
      followUps: prev.followUps.map(f => (f.id === id ? { ...f, ...updates } : f)),
    }))
  }, [])

  const dismissAlert = useCallback((id: string) => {
    setData(prev => ({
      ...prev,
      alerts: prev.alerts.map(a => (a.id === id ? { ...a, dismissed: true } : a)),
    }))
  }, [])

  const addRequest = useCallback((req: Omit<Request, 'id' | 'createdAt'>) => {
    setData(prev => ({
      ...prev,
      requests: [{ ...req, id: genId('r'), createdAt: new Date().toISOString() }, ...prev.requests],
    }))
  }, [])

  const updateRequest = useCallback((id: string, updates: Partial<Request>) => {
    setData(prev => ({
      ...prev,
      requests: prev.requests.map(r => (r.id === id ? { ...r, ...updates } : r)),
    }))
  }, [])

  const addLead = useCallback((lead: Omit<Lead, 'id' | 'createdAt'>) => {
    setData(prev => ({
      ...prev,
      leads: [{ ...lead, id: genId('lead'), createdAt: new Date().toISOString() }, ...prev.leads],
    }))
  }, [])

  const addNoteToCustomer = useCallback((customerId: string, note: string) => {
    setData(prev => ({
      ...prev,
      customers: prev.customers.map(c =>
        c.id === customerId ? { ...c, notes: [...(c.notes || []), note] } : c,
      ),
    }))
  }, [])

  const addOpportunity = useCallback((opp: Omit<Opportunity, 'id'>) => {
    setData(prev => ({
      ...prev,
      opportunities: [{ ...opp, id: genId('o') }, ...prev.opportunities],
    }))
  }, [])

  const addFollowUp = useCallback((fu: Omit<FollowUp, 'id'>) => {
    setData(prev => ({
      ...prev,
      followUps: [{ ...fu, id: genId('f') }, ...prev.followUps],
    }))
  }, [])

  const dismissFollowUp = useCallback((id: string) => {
    setData(prev => ({
      ...prev,
      followUps: prev.followUps.map(f => (f.id === id ? { ...f, status: 'Dismissed' as const } : f)),
    }))
  }, [])

  const resetData = useCallback(() => {
    localStorage.removeItem(STORAGE_KEY)
    setData(seedData)
  }, [])

  return (
    <StoreContext.Provider
      value={{
        data,
        updateOpportunity,
        updateFollowUp,
        dismissAlert,
        addRequest,
        updateRequest,
        addLead,
        addNoteToCustomer,
        addOpportunity,
        addFollowUp,
        dismissFollowUp,
        resetData,
      }}
    >
      {children}
    </StoreContext.Provider>
  )
}

export function useStore(): StoreContextValue {
  const ctx = useContext(StoreContext)
  if (!ctx) throw new Error('useStore must be used within StoreProvider')
  return ctx
}
